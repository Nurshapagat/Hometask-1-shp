/*package game;

import game.combat.CombatManager;
import game.enemies.Enemy;
import game.enemies.Zombie;
import game.items.ItemManager;
import game.level.LevelManager;
import game.player.Player;

public class MainGame {
    public static void main(String[] args) {
        Player player = new Player("Hero");
        CombatManager combatManager = new CombatManager(player);
        ItemManager itemManager = new ItemManager(player);
        LevelManager levelManager = new LevelManager(player, combatManager, itemManager);

        // Ойынды бастау
        levelManager.startGame();

        // Жау тудыру және шайқас бастау
        Enemy zombie = new Zombie();
        combatManager.fight(zombie);
    }
}*/
import player.Player;
import combat.CombatManager;
import enemies.Skeleton;
import enemies.Zombie;
import enemies.Vampire;
import items.GoldCoin;
import items.HealthElixir;
import items.MagicScroll;
import level.LevelManager;
import score.ScoreManager;

public class MainGame {
    public static void main(String[] args) {
        ScoreManager scoreManager = new ScoreManager();
        LevelManager levelManager = new LevelManager();
        Player player = new Player("Makpal", scoreManager);
        CombatManager combatManager = new CombatManager();

        Skeleton skeleton = new Skeleton();
        Zombie zombie = new Zombie();
        Vampire vampire = new Vampire();

        combatManager.fight(player, skeleton);
        combatManager.fight(player, zombie);
        combatManager.fight(player, vampire);

        levelManager.levelUp(player);

        player.pickUpItem(new HealthElixir());
        player.pickUpItem(new MagicScroll());
        player.pickUpItem(new GoldCoin());

        System.out.println("Final Score: " + player.getScore());
    }
}
