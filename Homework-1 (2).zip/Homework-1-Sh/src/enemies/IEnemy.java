package enemies;

public interface IEnemy {
    String getType();
    int getPoints();
}
