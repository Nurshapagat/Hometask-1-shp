package enemies;

public class Skeleton extends Enemy {
    public Skeleton() {
        super("Skeleton", 60);
    }
}
