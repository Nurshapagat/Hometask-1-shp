package enemies;

public class Vampire extends Enemy {
    public Vampire() {
        super("Vampire", 90);
    }
}