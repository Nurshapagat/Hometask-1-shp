/*package game.player;
import game.enemies.Enemy;

public class Player {
    private String name;
    private int health = 100;
    private int experience = 0;

    public Player(String name) {
        this.name = name;
    }

    public void takeDamage(int damage) {
        health -= damage;
    }

    public void attack(Enemy enemy) {
        enemy.takeDamage(10);
    }

    public void gainExperience(int xp) {
        experience += xp;
    }

    public int getHealth() { return health; }
    public String getName() { return name; }
}*/
        package player;

import score.ScoreManager;
import enemies.IEnemy;
import items.IItem;

public class Player {
    private String name;
    private ScoreManager scoreManager;

    public Player(String name, ScoreManager scoreManager) {
        this.name = name;
        this.scoreManager = scoreManager;
    }

    public String getName() {
        return name;
    }

    public void defeatEnemy(IEnemy enemy) {
        System.out.println(name + " defeated " + enemy.getType());
        scoreManager.updateScore(enemy.getPoints());
    }

    public void pickUpItem(IItem item) {
        item.use();
    }

    public int getScore() {
        return scoreManager.getScore();
    }
}
