/*package game.combat;
import game.player.Player;
import game.enemies.Enemy;

public class CombatManager {
    private Player player;

    public CombatManager(Player player) {
        this.player = player;
    }

    public void fight(Enemy enemy) {
        while (!enemy.isDefeated() && player.getHealth() > 0) {
            player.attack(enemy);
            enemy.attack(player);
            System.out.println(player.getName() + " vs " + enemy.getClass().getSimpleName());
        }
    }
}*/
package combat;

import player.Player;
import enemies.IEnemy;

public class CombatManager {
    public void fight(Player player, IEnemy enemy) {
        System.out.println(player.getName() + " is fighting " + enemy.getType());
        player.defeatEnemy(enemy);
    }
}

