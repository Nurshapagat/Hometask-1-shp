package items;

public class MagicScroll implements IItem {
    @Override
    public void use() {
        System.out.println("Magical knowledge gained!");
    }
}
