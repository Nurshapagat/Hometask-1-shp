package items;

public interface IItem {
    void use();
}