package items;

public class ItemManager {
    public void useItem(String item) {
        System.out.println("Using item: " + item);
    }
}