package game.level;
import game.player.Player;
import game.combat.CombatManager;
import game.items.ItemManager;

public class LevelManager {
    private Player player;
    private CombatManager combatManager;
    private ItemManager itemManager;

    public LevelManager(Player player, CombatManager combatManager, ItemManager itemManager) {
        this.player = player;
        this.combatManager = combatManager;
        this.itemManager = itemManager;
    }

    public void startGame() {
        System.out.println("Game started for " + player.getName());
    }
}