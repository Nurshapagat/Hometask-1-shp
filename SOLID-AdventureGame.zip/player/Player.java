package game.player;
import game.enemies.Enemy;

public class Player {
    private String name;
    private int health = 100;
    private int experience = 0;

    public Player(String name) {
        this.name = name;
    }

    public void takeDamage(int damage) {
        health -= damage;
    }

    public void attack(Enemy enemy) {
        enemy.takeDamage(10);
    }

    public void gainExperience(int xp) {
        experience += xp;
    }

    public int getHealth() { return health; }
    public String getName() { return name; }
}
