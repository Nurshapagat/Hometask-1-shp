package game;

import game.combat.CombatManager;
import game.enemies.Enemy;
import game.enemies.Zombie;
import game.items.ItemManager;
import game.level.LevelManager;
import game.player.Player;

public class MainGame {
    public static void main(String[] args) {
        Player player = new Player("Hero");
        CombatManager combatManager = new CombatManager(player);
        ItemManager itemManager = new ItemManager(player);
        LevelManager levelManager = new LevelManager(player, combatManager, itemManager);

        // Ойынды бастау
        levelManager.startGame();

        // Жау тудыру және шайқас бастау
        Enemy zombie = new Zombie();
        combatManager.fight(zombie);
    }
}
