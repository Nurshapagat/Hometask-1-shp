package game.enemies;
import game.player.Player;

public abstract class Enemy {
    protected String type;
    protected int health;

    public Enemy(String type, int health) {
        this.type = type;
        this.health = health;
    }

    public void takeDamage(int damage) {
        health -= damage;
    }

    public abstract void attack(Player player);
    public boolean isDefeated() { return health <= 0; }
}