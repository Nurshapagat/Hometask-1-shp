package enemies;
import game.enemies.Enemy;
public class Vampire {
}
