package game.enemies;
import game.player.Player;

public class Zombie extends Enemy {
    public Zombie() {
        super("Zombie", 50);
    }

    @Override
    public void attack(Player player) {
        player.takeDamage(10);
        System.out.println("Zombie attacks " + player.getName());
    }
}
