package items;

public class GoldCoin {
}
