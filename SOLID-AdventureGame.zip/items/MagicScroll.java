package items;

public class MagicScroll {
}
