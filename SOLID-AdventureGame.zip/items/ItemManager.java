package game.items;
import game.player.Player;

public class ItemManager {
    private Player player;

    public ItemManager(Player player) {
        this.player = player;
    }

    public void pickItem(String item) {
        System.out.println(player.getName() + " picked up " + item);
    }
}