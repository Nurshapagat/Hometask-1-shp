package score;

public interface ScoreManager {
    void updateScore(int points);
    int getScore();
}
